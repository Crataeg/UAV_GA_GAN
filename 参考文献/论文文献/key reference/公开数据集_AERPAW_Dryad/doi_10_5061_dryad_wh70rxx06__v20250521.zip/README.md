# Ericsson 5G NSA Network RF and Throughput Measurements on AERPAW Network

[https://doi.org/10.5061/dryad.wh70rxx06](https://doi.org/10.5061/dryad.wh70rxx06)

## Description of the data and file structure

This dataset contains radio frequency (RF) and throughput measurements from an Ericsson 5G Non-Standalone (NSA) network during a UAV zigzag flight mission on September 15, 2023, at yaw orientations of 45 and 315 degrees and specifically at an altitude of 30 meters. Measurements were taken using a Small Portable Node (SPN3) equipped with a Quectel 5G Modem. The data covers two sectors, focusing on both LTE and NR technologies.

### Files and variables

#### File: Dryad.zip

### Methodology

* Instruments: Small Portable Node SPN3, Quectel 5G Modem
* Experimental Setup: UAV flight testing in zigzag patterns at specified altitude with RF and throughput logging for yaw45 and yaw315 orientations.
* Data Processing: Use the provided MATLAB scripts for post-processing RF measurement data, which includes calculations and visualizations such as 3D scatter plots, distance vs. time analyses, and statistical distributions (PDF and CDF).

### Data Files Description

Detailed information for each file within the `yaw45` and `yaw315` folders:

* **input_throughput_with_header.csv**: Time and date, Longitude, Latitude, Altitude, and Throughput (Mbps). Throughput measurements, expressed in Mbps, quantify the data transmission rate achieved during the UAV's flight, capturing performance variations due to different yaw orientations and altitudes.
* **inputf1_sinr_with_header.csv** and **inputf2_sinr_with_header.csv**: Time and date, Longitude, Latitude, Altitude, and LTE/NR SINR (dB). SINR data, provided in dB, offers insights into the quality of the signal relative to the background noise and interference, critical for assessing communication reliability.
* **inputf1_cellid_with_header.csv** and **inputf2_cellid_with_header.csv**: Time and date, Longitude, Latitude, Altitude, and LTE/NR Cell ID. Cell ID information helps identify the specific LTE and NR cells engaged during the UAV’s flight path, illustrating the network's cell distribution and usage.
* **inputf1_rsrp_with_header.csv** and **inputf2_rsrp_with_header.csv**: Time and date, Longitude, Latitude, Altitude, LTE/NR RSRP (dBm). RSRP values, recorded in dBm, indicate the power level of the reference signals received from the cell, essential for evaluating signal strength and link quality.
* **inputf2_cqi_with_header.csv**: Time and date, Longitude, Latitude, Altitude, and NR Channel Quality Information (CQI). CQI reports provide an evaluation of the channel quality experienced, influencing the network's adaptive modulation and coding decisions for optimized performance.
* **inputf2_mcs_with_header.csv**: Time and date, Longitude, Latitude, Altitude, and NR Modulation and Coding Scheme (MCS). MCS data reveals the modulation and coding techniques applied, reflecting the efficiency of data transmission under varying channel conditions.
* **inputf2_ri_with_header.csv**: Time and date, Longitude, Latitude, Altitude, and NR Rank Indicator (RI). Rank Indicator values determine the number of transmission layers used in MIMO communications, pivotal for understanding spatial multiplexing capabilities.

Additional files included at each folders:

* **`..._iperfclient_log.txt`**: Raw iperf3 log capturing throughput in real-time (interval, transfer size, and bandwidth in Mbits/sec)
* **`..._vehicleOut.txt`**: Vehicle telemetry including geolocation, orientation, speed, and timestamp
* **`Basic_and_Other_Params.csv`**: Configuration of LTE/NR CSI parameters (MCS, RI, CQI, PMI) for both technologies
* **`Serving_cell_Params_ENDC.csv`**: Serving cell configurations, including LTE and NR5G-NSA parameters such as RSRP, SINR, ARFCN, band, and subcarrier spacing

## Supporting and Advanced Files

### ...\_vehicleOut.txt

Vehicle telemetry log recorded during the UAV flight. This file provides time-synchronized motion and positioning data, essential for analyzing the UAV’s orientation, velocity, and location during RF measurements.

#### Columns and Descriptions

| Column               | Description                                     |
| -------------------- | ----------------------------------------------- |
| `num`                | Frame index or line number (incremental).       |
| `Longitude`          | GPS longitude coordinate (in degrees).          |
| `Latitude`           | GPS latitude coordinate (in degrees).           |
| `Altitude`           | UAV altitude above ground (in meters).          |
| `Pitch`              | UAV pitch angle (in radians).                   |
| `Yaw`                | UAV yaw angle (in radians).                     |
| `Roll`               | UAV roll angle (in radians).                    |
| `VelocityX`          | Velocity in the X direction (in meters/second). |
| `VelocityY`          | Velocity in the Y direction (in meters/second). |
| `VelocityZ`          | Velocity in the Z direction (in meters/second). |
| `BatteryVolts`       | Battery voltage level of the UAV (in volts).    |
| `time`               | Timestamp of the telemetry data.                |
| `GPSFix`             | GPS fix status.                                 |
| `NumberOfSatellites` | Number of GPS satellites in view.               |

### Basic\_and\_Other\_Params.csv

Contains LTE and NR channel state information (CSI) parameters based on `+QNWCFG` AT command responses. These values reflect the physical-layer configuration and adaptation based on current channel conditions.

#### LTE CSI

| Column    | Description                                                                |
| --------- | -------------------------------------------------------------------------- |
| `lte_mcs` | LTE MCS index (0–31). Indicates modulation and coding scheme.              |
| `lte_ri`  | LTE Rank Indicator. Number of MIMO layers used in transmission.            |
| `lte_cqi` | LTE Channel Quality Indicator. Assesses downlink channel quality.          |
| `lte_pmi` | LTE Precoding Matrix Index. Indicates preferred beamforming configuration. |

#### NR5G CSI

| Column     | Description                                                                 |
| ---------- | --------------------------------------------------------------------------- |
| `nr5g_mcs` | NR MCS index (0–31). Reflects spectral efficiency under current conditions. |
| `nr5g_ri`  | NR Rank Indicator. Number of spatial streams used.                          |
| `nr5g_cqi` | NR Channel Quality Indicator. Measures channel quality for NR.              |
| `nr5g_pmi` | NR Precoding Matrix Index. Beamforming configuration indicator.             |

---

### Serving\_cell\_Params\_ENDC.csv

Includes detailed LTE and NR5G-NSA serving cell parameters collected using `+QENG` AT command responses. These parameters are essential for understanding the operating conditions of the serving LTE and NR cells, including signal strength, quality, band configuration, and network identifiers.

#### LTE Fields

| Field           | Description                                                                    |
| --------------- | ------------------------------------------------------------------------------ |
| `is_tdd`        | Duplexing mode: TDD (Time Division Duplex) or FDD (Frequency Division Duplex). |
| `MCC`           | Mobile Country Code identifying the LTE network's country.                     |
| `MNC`           | Mobile Network Code identifying the LTE operator.                              |
| `cellID`        | E-UTRAN Cell Identifier (ECI), uniquely identifies the LTE cell.               |
| `PCID`          | Physical Cell ID used for LTE synchronization.                                 |
| `earfcn`        | Absolute RF Channel Number representing LTE frequency.                         |
| `freq_band_ind` | LTE band number (e.g., 66 for Band 66).                                        |
| `UL_bandwidth`  | Uplink bandwidth code (0–5; where 5 = 20 MHz).                                 |
| `DL_bandwidth`  | Downlink bandwidth code (0–5; where 5 = 20 MHz).                               |
| `TAC`           | Tracking Area Code used for LTE mobility management.                           |
| `RSRP`          | Reference Signal Received Power (in dBm), LTE signal strength.                 |
| `RSRQ`          | Reference Signal Received Quality (in dB).                                     |
| `RSSI`          | Received Signal Strength Indicator (in dBm), total received power.             |
| `SINR`          | Signal-to-Interference-plus-Noise Ratio (in dB).                               |
| `CQI`           | Channel Quality Indicator (0–15) for adaptive modulation.                      |
| `tx_power`      | UE transmit power (in dBm), if available.                                      |
| `srxlev`        | Signal reception level used for LTE cell selection.                            |

#### NR5G Fields

| Field               | Description                                               |
| ------------------- | --------------------------------------------------------- |
| `NR5G_MCC`          | Mobile Country Code for the 5G NR network.                |
| `NR5G_MNC`          | Mobile Network Code for the 5G NR network operator.       |
| `NR5G_PCID`         | Physical Cell ID of the NR cell.                          |
| `NR5G_RSRP`         | NR Reference Signal Received Power (in dBm).              |
| `NR5G_SINR`         | NR Signal-to-Interference-plus-Noise Ratio (in dB).       |
| `NR5G_RSRQ`         | NR Reference Signal Received Quality (in dB).             |
| `NR5G_ARFCN`        | Absolute RF Channel Number for NR.                        |
| `NR5G_band`         | NR frequency band number (e.g., 77 for n77).              |
| `NR5G_DL_bandwidth` | Downlink bandwidth of the NR carrier (in MHz).            |
| `NR5G_scs`          | Subcarrier spacing used in NR (in kHz; e.g., 15, 30, 60). |

### Glossary of Abbreviations

| Abbreviation | Full Term                                                                 |
| ------------ | ------------------------------------------------------------------------- |
| LTE          | Long-Term Evolution (4G wireless broadband technology)                    |
| NR           | New Radio (5G wireless communication standard)                            |
| NSA          | Non-Standalone (5G deployment using LTE as anchor)                        |
| RSRP         | Reference Signal Received Power (dBm)                                     |
| RSRQ         | Reference Signal Received Quality (dB)                                    |
| SINR         | Signal-to-Interference-plus-Noise Ratio (dB)                              |
| RSSI         | Received Signal Strength Indicator (dBm)                                  |
| CQI          | Channel Quality Indicator (index indicating DL channel quality)           |
| MCS          | Modulation and Coding Scheme (index determining data rate and robustness) |
| RI           | Rank Indicator (number of spatial MIMO layers used)                       |
| PMI          | Precoding Matrix Indicator (preferred beamforming index)                  |
| PCID         | Physical Cell ID (unique identifier for a radio cell)                     |
| MCC          | Mobile Country Code (cell network country identifier)                     |
| MNC          | Mobile Network Code (cell network operator identifier)                    |
| EARFCN       | E-UTRA Absolute Radio Frequency Channel Number (LTE frequency index)      |
| ARFCN        | Absolute Radio Frequency Channel Number (NR frequency index)              |
| TAC          | Tracking Area Code (used for LTE mobility management)                     |
| DL           | Downlink (network to device transmission)                                 |
| UL           | Uplink (device to network transmission)                                   |
| SCS          | Subcarrier Spacing (distance between subcarriers in NR, in kHz)           |
| TDD          | Time Division Duplex (uplink and downlink share same frequency)           |
| FDD          | Frequency Division Duplex (uplink and downlink use separate frequencies)  |
| ECI          | E-UTRAN Cell Identifier (LTE cell ID)                                     |

### Related Documents

* Include the MATLAB processing script (`example.m`) as a supplementary file to aid in understanding and reproducing the results.

## Access information

Other publicly accessible locations of the data:

* [https://aerpaw.org/dataset/aerpaw-ericsson-5g-uav-experiment/](https://aerpaw.org/dataset/aerpaw-ericsson-5g-uav-experiment/)

